%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Dr. Jan Wendel                   %
% Integrierte Navigationssysteme   %
% 2. Auflage                       %
% ISBN 978-3-486-70439-6           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Matlab-Code zum Beispiel Abschnitt 7.3.5, S. 184 ff. %
% (C) Jan Wendel                                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pendulum_simulation
    clear
    clc
    close all

    steps = 25000;              % Anzahl der Zeitschritte der Simulation
    dt = 0.01;                  % Zeitschrittweite des Filters
    timestamp_filter = 100;     % Anzahl der Zeitschritte zwischen zwei Filteraufrufen; der Filter wird nicht in jedem Simulationszeitschritt aufgerufen
    timestamp_measurement = 2*timestamp_filter; % Anzahl der Zeitschritte zwischen zwei Zeitpunkten, an denen Messwerte vorliegen
    timestamp_save = timestamp_measurement; % Anzahl der Zeitschritte zwischen zwei Zeitpunkten, an denen Ergebnisse gespeichert werden
    dt_rw = dt/timestamp_filter; % Zeitschrittweite der Simulation

    data = zeros(ceil(steps/timestamp_save),5);
    save_counter = 1;
    
    pend.g = 9.81;     % Schwerebeschleunigung m/s^2
    pend.length = 1.0; % Laenge des Pendels

    init_angle = 50.0; % Anfangswinkel in Grad, mit dem die Filter initialisiert werden
                       % In Zeile 39 wird das Pendel mit dem negativen
                       % dieses Wertes initialisiert, dieser Wert
                       % entspricht daher dem halben Winkelanfangsfehler
                       % 50 funktioniert noch fuer den Kalman Filter, 
                       % bei 60 divergiert der Kalman Filter in der Regel, 
                       % waehrend der Partikelfilter noch funktioniert
    
    pend.X = [-init_angle/180*pi;0]; % Anfangszustand des Pendels: Winkel, Winkelgeschwindigkeit
    pend.R = 0.1^2;                  % Varianz des Messrauschens
    pend.cholR = sqrt(pend.R);       % Standardabweichung des Messrauschens

    
    pf = pf_filter_init(init_angle); % PF Initialisierung
    kf = kf_filter_init(init_angle); % KS Initialisierung

    disp('Taste druecken...')
    show_pf_distribution(pf,kf,pend);
    
    
    % Simulationsschleife
    for count=1:steps
    
        % Propagation der Referenz ('reale Welt')
        tmp = pend.X(1);
        pend.X(1) = pend.X(1) + pend.X(2)*dt_rw;
        pend.X(2) = pend.X(2) - pend.g/pend.length*sin(tmp)*dt_rw;
    
        if (mod(count,timestamp_filter) == 0) % Soll der Filter aufgerufen werden ?
         
            pf = pf_filter_propagation(pf,pend,dt); % PF Propagationsschritt
            kf = kf_filter_propagation(kf,pend,dt); % KF Propagationsschritt
            
            if (mod(count,timestamp_measurement) == 0) % Liegt ein Messwert vor ?
                y = pend.length*sin(pend.X(1)) +  randn(1)*pend.cholR; % Messwert aus realem Wert + Rauschen erzeugen

                pf = pf_filter_estimation(pf,pend,y); % PF Messschritt
                kf = kf_filter_estimation(kf,pend,y); % KF Messschritt
            end
   
        end

        if (mod(count-1,timestamp_save) == 0) % store the data
            data(save_counter,1) = count*dt_rw;
            data(save_counter,2) = pend.X(1);
            data(save_counter,3) = pend.X(2);
            data(save_counter,4) = pf.X(1,:)*pf.w(:);
            data(save_counter,5) = pf.X(2,:)*pf.w(:);
            data(save_counter,6) = kf.X(1);
            data(save_counter,7) = kf.X(2);
            save_counter = save_counter + 1;
            show_pf_distribution(pf,kf,pend);
        end
        if (count == 1) pause; end
    end
    
    figure(2);
    clf
    plot(data(:,1),180/pi*data(:,2),'r','Linewidth',3)
    hold on
    plot(data(:,1),180/pi*data(:,4),'g','Linewidth',3)
    plot(data(:,1),180/pi*data(:,6),'b','Linewidth',3);
    hold off
    legend('True','pf','kf')
    grid on
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pf = pf_filter_init(init_angle)
    pf.num = 300;                         % Anzahl der Partikel
    pf.X = zeros(2,pf.num);               % Partikel anlegen
    pf.w = 1/pf.num*ones(1,pf.num);       % Gewichte
    pf.Q = [(1/180*pi)^2, 0;              % Systemrauschen definieren
                  0,    (1e-4)^2];
    pf.cholQ = chol(pf.Q);
    pf.R = 0.1^2;                         % Varianz der Messungen
    pf.Xs = [init_angle/180*pi;0];        % Initialer Zustand
    pf.Ps = [(init_angle/180*pi)^2,0;     % Initiale Unsicherheit
                    0,    (10/180*pi)^2];
          
    % Ziehen der Partikel entsprechend initalem Zustand/Unsicherheit            
    cholP = chol(pf.Ps);
    for k=1:pf.num 
        pf.X(:,k) = cholP*randn(2,1) + pf.Xs;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pf = pf_filter_propagation(pf,pend,dt)
    % Propagation der Partikel entsprechend dem Systemmodell
    % und dem Systemrauschen
    for k=1:pf.num
       tmp = pf.X(1,k);
       pf.X(1,k) = pf.X(1,k) + pf.X(2,k)*dt + randn(1)*pf.cholQ(1,1);
       pf.X(2,k) = pf.X(2,k) - pend.g/pend.length*sin(tmp)*dt + randn(1)*pf.cholQ(2,2);

       if (pf.X(1,k) > pi) % Winkelbereich auf +/- 180� beschr�nken
           pf.X(1,k) = pf.X(1,k) - 2*pi; 
       end
       if (pf.X(1,k) < -pi)
           pf.X(1,k) = pf.X(1,k) + 2*pi; 
       end
       
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pf = pf_filter_estimation(pf,pend,y)
    for k=1:pf.num
        pf.w(k) = exp(-1/2*(y - pend.length*sin(pf.X(1,k)))^2/pf.R);
    end
    pf.w = pf.w/sum(pf.w);       

    peff = 1/sum(pf.w.^2); % Anzahl der effiktiven Partikel bestimmen
    if (peff<0.7*pf.num)   % Resampling notwendig ?
        top(1) = pf.w(1); 
        for k=1:pf.num-1   % Intervallgrenzen festlegen
            top(k+1) = top(k) + pf.w(k+1);
        end
        pf.resampled = zeros(2,pf.num);  
        for k=1:pf.num
            zf = rand(1);  % gleichverteilte Zufallszahl ziehen
            for j=1:pf.num % zugeh�riges Intervall suchen
                if (top(j)>zf)
                    pf.resampled(:,k) = pf.X(:,j); % zugeh�rigen Partikel
                    break;                         % reproduzieren
                end
            end
        end
        pf.X = pf.resampled;
    end 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function kf = kf_filter_init(init_angle)
    kf.Q = [(1/180*pi)^2, 0;           % Systemrauschen definieren
                  0,    (1e-4)^2];
    kf.R = 0.1^2;                      % Varianz der Messwerte
    kf.X = [init_angle/180*pi;0];      % Initialer Zustand
    kf.P = [(init_angle/180*pi)^2,0;   % Initiale Unsicherheit
                 0,    (10/180*pi)^2];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function kf = kf_filter_propagation(kf,pend,dt)
   % Zustandssch�tzung propagieren
   tmp = kf.X(1);
   kf.X(1) = kf.X(1) + kf.X(2)*dt;
   kf.X(2) = kf.X(2) - pend.g/pend.length*sin(tmp)*dt;

   % Jacobi-Matrix der Systemmodell-DGL berechnen
   Phi = [1                              , dt;  
          -pend.g/pend.length*cos(tmp)*dt,  1];
   
   % Kovarianzmatrix des Sch�tzfehlers propagieren
   kf.P = Phi*kf.P*Phi' + kf.Q;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function kf = kf_filter_estimation(kf,pend,y)
    y_pred = pend.length*sin(kf.X(1));  % Messwert-Vorhersage
    H = [pend.length*cos(kf.X(1)), 0];  % Messmatrix
    
    K = kf.P*H'*inv(H*kf.P*H' + kf.R);  % Kalman Gain Matrix
    kf.X = kf.X - K*(y_pred - y);       % Zustandssch�tzung updaten
    % Update der Kovarianzmatrix des Sch�tzfehlers (Joseph's Form)
    kf.P = (eye(2) - K*H)*kf.P*(eye(2) - K*H)' + K*kf.R*K';
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function show_pf_distribution(pf,kf,pend)
%     figure(1);
%     subplot(2,1,1)
%     x = pend.length*sin(pend.X(1));
%     y = pend.length*(-cos(pend.X(1)));
%     plot([0,x],[0,y],'m','LineWidth',3);
%     legend('Pendulum');
%     axis([-1.2*pend.length,1.2*pend.length,-1.2*pend.length,1.2*pend.length]);
%     
%    subplot(2,1,2)
    plot(pf.X(1,:)*180/pi,pf.X(2,:)*180/pi,'.r');
    xlabel('angle (deg)');
    ylabel('rate (deg/s)');
    hold on
    p_angle = pf.X(1,:)*pf.w(:);
    p_rate = pf.X(2,:)*pf.w(:);
    plot(p_angle*180/pi,p_rate*180/pi,'.g');        
    plot(kf.X(1)*180/pi,kf.X(2)*180/pi,'.b');
    plot(pend.X(1)*180/pi,pend.X(2)*180/pi,'.k');
    legend('pf distribution','pf estimate','kf estimate','Pendulum state');
    hold off
    grid on
    axis([-180,180,-300,300]);
    drawnow
end
