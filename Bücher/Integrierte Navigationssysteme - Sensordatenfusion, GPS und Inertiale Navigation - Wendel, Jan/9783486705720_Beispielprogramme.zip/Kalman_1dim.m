%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Dr. Jan Wendel                   %
% Integrierte Navigationssysteme   %
% 2. Auflage                       %
% ISBN 978-3-486-70439-6           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Kalman_1dim

clear
clc
close all

N  = 1000;               % Anzahl der Zeitschritte der Simulation
dt = 0.1;                % Zeitschrittweite
timestamp_gps = 10;      % Anzahl der Zeitschritte zwischen zwei Positionsmessungen
data = zeros(N,7);       % store results:

% -----------------------------------------------------
% Sensordaten
% -----------------------------------------------------
Var_AccNoise = 0.01;  % Varianz Beschleunigungsmessung [(m/s^2)^2]
Var_GpsNoise = 100;   % Varianz Positionsmessung [m^2]
AccBias      = 0.1;   % Bias Beschleunigungsmesser [m/s^2]

R_Acc = Var_AccNoise; % zur Uebergabe an Kalman Filter
R_Gps = Var_GpsNoise; % zur Uebergabe an Kalman Filter

% -----------------------------------------------------
% Erzeugen einer Trajektorie
% -----------------------------------------------------
disp('Erzeuge Trajektorie...')
real_acc = zeros(N,1);
real_velo = zeros(N,1);
real_pos = zeros(N,1);
for i=1:N;
    real_acc(i) = sin(4*pi*i/N);
    data(i,1) = (i-1)*dt;
end;
for i = 2:N
    real_pos(i) = real_pos(i-1) + real_velo(i-1)*dt + 1/2*real_acc(i)*dt^2;
    real_velo(i) =                real_velo(i-1)    +     real_acc(i)*dt;
end;


kf = kf_init(real_pos(1)+50, real_velo(1) + 10, dt); % KF mit Anfangsfehlern initialisieren


% -----------------------------------------------------
% Simulation:
% -----------------------------------------------------

disp('Simulation ...')
for k = 1:N

    % -----------------------------------------------------
    % Estimation
    % -----------------------------------------------------

    if (mod(k,timestamp_gps) == 0)
        Gps_measurement = real_pos(k,1) + sqrt(Var_GpsNoise) * randn(1);

        kf = kf_estimation(kf, Gps_measurement, R_Gps); % Positionsmessung verarbeiten

    end

    % ----------------------------------------------------
    % Preediktion
    % ----------------------------------------------------
    Acc_measurement = real_acc(k,1) + AccBias + sqrt(Var_AccNoise) * randn(1);

    kf = kf_propagation(kf, Acc_measurement, R_Acc);

    data(k,2:4) = kf.X';
    data(k,5) = kf.P(1,1);
    data(k,6) = kf.P(2,2);
    data(k,7) = kf.P(3,3);

end

plot_results(data, real_pos, real_velo, AccBias);

end




% -----------------------------------------------------
% Initialisierung des Kalman Filters
% -----------------------------------------------------
function kf = kf_init(pos,vel,dt)
kf.X = [pos; vel; 0];			   % Kalman Zuistandsvektor x,v,b
kf.Phi = [1     dt -1/2*dt^2;      % Transitionsmatrix
          0     1    -dt ;
          0     0     1];
kf.H_Gps = [1 0 0];	           % Messmatrix Positionsmessung
kf.P = [2500   0    0;             % Kovarianzmatrix des Schaetzfehlers
        0	  100   0;
        0	   0    0.01];
kf.dt = dt;
end

% -----------------------------------------------------
% Kalman Filter Praediktionsschritt
% -----------------------------------------------------
function kf = kf_propagation(kf, Acc_measurement, R_Acc)

B = [1/2*kf.dt^2;
    kf.dt;
    0];
kf.X = kf.Phi * kf.X + B * Acc_measurement;


Qk = zeros(3);
Qk(2,2) = R_Acc; % Grobe Naeherung, aber hier ausreichend
kf.P = kf.Phi * kf.P * kf.Phi' + Qk;

end


% -----------------------------------------------------
% Kalman Filter Estimationsschritt
% -----------------------------------------------------
function kf = kf_estimation(kf, Gps_measurement, R_Gps)
K = kf.P * kf.H_Gps' * inv(kf.H_Gps * kf.P * kf.H_Gps' + R_Gps);
kf.X = kf.X - K * (kf.H_Gps * kf.X - Gps_measurement);
kf.P = kf.P - K * kf.H_Gps * kf.P;
end

% -----------------------------------------------------
% Plot der Ergebnisse
% -----------------------------------------------------
function plot_results(data, real_pos, real_velo, AccBias)
figure(1)
plot(data(:,1),data(:,2)-real_pos,'b','Linewidth',2)
hold on
plot(data(:,1),3*data(:,5).^0.5,'r','Linewidth',1)
plot(data(:,1),-3*data(:,5).^0.5,'r','Linewidth',1)
hold off
legend('Schaetzfehler Pos.','Selbsteinschaetzung 3\sigma')
xlabel('Zeit (s)')
ylabel('(m)')
grid on

figure(2)
plot(data(:,1),data(:,3)-real_velo,'b','Linewidth',2)
hold on
plot(data(:,1),3*data(:,6).^0.5,'r','Linewidth',1)
plot(data(:,1),-3*data(:,6).^0.5,'r','Linewidth',1)
hold off
legend('Schaetzfehler Vel.','Selbsteinschaetzung 3\sigma')
xlabel('Zeit (s)')
ylabel('(m/s)')
grid on

figure(3)
plot(data(:,1),data(:,4)-AccBias,'b','Linewidth',2)
hold on
plot(data(:,1),3*data(:,7).^0.5,'r','Linewidth',1)
plot(data(:,1),-3*data(:,7).^0.5,'r','Linewidth',1)
hold off
legend('Schaetzfehler AccBias','Selbsteinschaetzung 3\sigma')
xlabel('Zeit (s)')
ylabel('(m/s^2)')
grid on

figure(4)
subplot(3,1,1)
plot(data(:,1),real_pos,'g','Linewidth',2)
hold on
plot(data(:,1),data(:,2),'b','Linewidth',2)
hold off
legend('Reale Pos.','Geschaetzte Pos.')
ylabel('(m)')
grid on

subplot(3,1,2)
plot(data(:,1),real_velo,'g','Linewidth',2)
hold on
plot(data(:,1),data(:,3),'b','Linewidth',2)
hold off
legend('Reale Vel.','Geschaetzte Vel.')
ylabel('(m/s)')
grid on

subplot(3,1,3)
plot(data(:,1),AccBias*ones(size(data(:,1))),'g','Linewidth',2)
hold on
plot(data(:,1),data(:,4),'b','Linewidth',2)
hold off
legend('Realer AccBias','Geschaetzter AccBias')
xlabel('Zeit (s)')
ylabel('(m/s^2)')
grid on


end


